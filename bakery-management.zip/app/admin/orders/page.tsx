"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Eye, Filter, Search, Truck } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Define order type
interface OrderItem {
  productId: string
  productName: string
  quantity: number
  unitPrice: number
}

interface Order {
  id: string
  referenceId: string
  bakeryId: string
  bakeryName: string
  status: "PENDING" | "IN_PROGRESS" | "READY_FOR_DELIVERY" | "DELIVERING" | "DELIVERED" | "CANCELLED"
  items: OrderItem[]
  totalPrice: number
  notes: string
  createdAt: string
}

// Sample data
const initialOrders: Order[] = [
  {
    id: "1",
    referenceId: "CMD-2025-001",
    bakeryId: "2",
    bakeryName: "Boulangerie Saint-Michel",
    status: "PENDING",
    items: [
      { productId: "1", productName: "Baguette Tradition", quantity: 50, unitPrice: 1.2 },
      { productId: "2", productName: "Pain au Chocolat", quantity: 30, unitPrice: 1.5 },
    ],
    totalPrice: 105,
    notes: "Livraison avant 7h du matin",
    createdAt: "2025-04-22T06:30:00Z",
  },
  {
    id: "2",
    referenceId: "CMD-2025-002",
    bakeryId: "3",
    bakeryName: "Boulangerie Montmartre",
    status: "IN_PROGRESS",
    items: [
      { productId: "1", productName: "Baguette Tradition", quantity: 40, unitPrice: 1.2 },
      { productId: "3", productName: "Croissant", quantity: 25, unitPrice: 1.3 },
      { productId: "4", productName: "Pain aux Céréales", quantity: 15, unitPrice: 2.8 },
    ],
    totalPrice: 115.5,
    notes: "",
    createdAt: "2025-04-22T07:15:00Z",
  },
  {
    id: "3",
    referenceId: "CMD-2025-003",
    bakeryId: "2",
    bakeryName: "Boulangerie Saint-Michel",
    status: "READY_FOR_DELIVERY",
    items: [
      { productId: "1", productName: "Baguette Tradition", quantity: 30, unitPrice: 1.2 },
      { productId: "2", productName: "Pain au Chocolat", quantity: 20, unitPrice: 1.5 },
      { productId: "3", productName: "Croissant", quantity: 20, unitPrice: 1.3 },
    ],
    totalPrice: 92,
    notes: "Commande urgente",
    createdAt: "2025-04-22T08:00:00Z",
  },
  {
    id: "4",
    referenceId: "CMD-2025-004",
    bakeryId: "3",
    bakeryName: "Boulangerie Montmartre",
    status: "DELIVERING",
    items: [
      { productId: "1", productName: "Baguette Tradition", quantity: 25, unitPrice: 1.2 },
      { productId: "4", productName: "Pain aux Céréales", quantity: 10, unitPrice: 2.8 },
    ],
    totalPrice: 58,
    notes: "",
    createdAt: "2025-04-21T16:45:00Z",
  },
  {
    id: "5",
    referenceId: "CMD-2025-005",
    bakeryId: "2",
    bakeryName: "Boulangerie Saint-Michel",
    status: "DELIVERED",
    items: [
      { productId: "1", productName: "Baguette Tradition", quantity: 45, unitPrice: 1.2 },
      { productId: "2", productName: "Pain au Chocolat", quantity: 35, unitPrice: 1.5 },
      { productId: "3", productName: "Croissant", quantity: 30, unitPrice: 1.3 },
    ],
    totalPrice: 142.5,
    notes: "",
    createdAt: "2025-04-21T07:30:00Z",
  },
  {
    id: "6",
    referenceId: "CMD-2025-006",
    bakeryId: "3",
    bakeryName: "Boulangerie Montmartre",
    status: "CANCELLED",
    items: [
      { productId: "1", productName: "Baguette Tradition", quantity: 20, unitPrice: 1.2 },
      { productId: "3", productName: "Croissant", quantity: 15, unitPrice: 1.3 },
    ],
    totalPrice: 43.5,
    notes: "Commande annulée par le client",
    createdAt: "2025-04-21T18:20:00Z",
  },
]

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>(initialOrders)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [viewingOrder, setViewingOrder] = useState<Order | null>(null)
  const [isAssignDeliveryDialogOpen, setIsAssignDeliveryDialogOpen] = useState(false)
  const [orderToAssign, setOrderToAssign] = useState<Order | null>(null)
  const [selectedDeliveryPerson, setSelectedDeliveryPerson] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const { toast } = useToast()

  // Filter orders based on search term and status
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.referenceId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.bakeryName.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || order.status === statusFilter

    const matchesTab =
      activeTab === "all" ||
      (activeTab === "pending" && order.status === "PENDING") ||
      (activeTab === "in_progress" && order.status === "IN_PROGRESS") ||
      (activeTab === "ready" && order.status === "READY_FOR_DELIVERY") ||
      (activeTab === "delivering" && order.status === "DELIVERING") ||
      (activeTab === "delivered" && order.status === "DELIVERED") ||
      (activeTab === "cancelled" && order.status === "CANCELLED")

    return matchesSearch && matchesStatus && matchesTab
  })

  // Handle delivery assignment
  const handleAssignDelivery = () => {
    if (!orderToAssign || !selectedDeliveryPerson) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un livreur",
        variant: "destructive",
      })
      return
    }

    // In a real app, this would make an API call to assign the delivery
    toast({
      title: "Livraison assignée",
      description: `La commande ${orderToAssign.referenceId} a été assignée au livreur ${selectedDeliveryPerson}`,
    })

    // Update order status to DELIVERING
    const updatedOrders = orders.map((order) =>
      order.id === orderToAssign.id ? { ...order, status: "DELIVERING" as const } : order,
    )
    setOrders(updatedOrders)
    setIsAssignDeliveryDialogOpen(false)
    setOrderToAssign(null)
    setSelectedDeliveryPerson("")
  }

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  // Format price
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("fr-FR", {
      style: "currency",
      currency: "EUR",
    }).format(price)
  }

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "PENDING":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            En attente
          </Badge>
        )
      case "IN_PROGRESS":
        return <Badge variant="secondary">En préparation</Badge>
      case "READY_FOR_DELIVERY":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Prêt à livrer
          </Badge>
        )
      case "DELIVERING":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            En livraison
          </Badge>
        )
      case "DELIVERED":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Livré
          </Badge>
        )
      case "CANCELLED":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Annulé
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <DashboardLayout role="admin">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Commandes</h1>
            <p className="text-muted-foreground">Gérez et suivez toutes les commandes</p>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 md:grid-cols-7 mb-4">
            <TabsTrigger value="all">Toutes</TabsTrigger>
            <TabsTrigger value="pending">En attente</TabsTrigger>
            <TabsTrigger value="in_progress">En préparation</TabsTrigger>
            <TabsTrigger value="ready">Prêt à livrer</TabsTrigger>
            <TabsTrigger value="delivering">En livraison</TabsTrigger>
            <TabsTrigger value="delivered">Livrées</TabsTrigger>
            <TabsTrigger value="cancelled">Annulées</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Liste des commandes</CardTitle>
                <CardDescription>{filteredOrders.length} commandes trouvées</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4 flex flex-col sm:flex-row items-start sm:items-center gap-2">
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <Search className="h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Rechercher une commande..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="max-w-sm"
                    />
                  </div>
                  <div className="flex items-center gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                    <Filter className="h-4 w-4 text-muted-foreground" />
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Filtrer par statut" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tous les statuts</SelectItem>
                        <SelectItem value="PENDING">En attente</SelectItem>
                        <SelectItem value="IN_PROGRESS">En préparation</SelectItem>
                        <SelectItem value="READY_FOR_DELIVERY">Prêt à livrer</SelectItem>
                        <SelectItem value="DELIVERING">En livraison</SelectItem>
                        <SelectItem value="DELIVERED">Livré</SelectItem>
                        <SelectItem value="CANCELLED">Annulé</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Référence</TableHead>
                        <TableHead>Boulangerie</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Montant</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredOrders.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8">
                            Aucune commande trouvée
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredOrders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">{order.referenceId}</TableCell>
                            <TableCell>{order.bakeryName}</TableCell>
                            <TableCell>{formatDate(order.createdAt)}</TableCell>
                            <TableCell>{formatPrice(order.totalPrice)}</TableCell>
                            <TableCell>{getStatusBadge(order.status)}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Dialog
                                  open={isViewDialogOpen && viewingOrder?.id === order.id}
                                  onOpenChange={(open) => {
                                    setIsViewDialogOpen(open)
                                    if (open) setViewingOrder(order)
                                  }}
                                >
                                  <DialogTrigger asChild>
                                    <Button variant="ghost" size="icon">
                                      <Eye className="h-4 w-4" />
                                      <span className="sr-only">Voir</span>
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="max-w-3xl">
                                    <DialogHeader>
                                      <DialogTitle>Détails de la commande {order.referenceId}</DialogTitle>
                                    </DialogHeader>
                                    {viewingOrder && (
                                      <div className="grid gap-4 py-4">
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                          <div>
                                            <h3 className="font-medium">Informations générales</h3>
                                            <div className="mt-2 space-y-2">
                                              <div className="flex justify-between">
                                                <span className="text-muted-foreground">Référence:</span>
                                                <span>{viewingOrder.referenceId}</span>
                                              </div>
                                              <div className="flex justify-between">
                                                <span className="text-muted-foreground">Boulangerie:</span>
                                                <span>{viewingOrder.bakeryName}</span>
                                              </div>
                                              <div className="flex justify-between">
                                                <span className="text-muted-foreground">Date:</span>
                                                <span>{formatDate(viewingOrder.createdAt)}</span>
                                              </div>
                                              <div className="flex justify-between">
                                                <span className="text-muted-foreground">Statut:</span>
                                                <span>{getStatusBadge(viewingOrder.status)}</span>
                                              </div>
                                            </div>
                                          </div>
                                          <div>
                                            <h3 className="font-medium">Notes</h3>
                                            <p className="mt-2 text-sm">{viewingOrder.notes || "Aucune note"}</p>
                                          </div>
                                        </div>
                                        <div>
                                          <h3 className="font-medium mb-2">Produits commandés</h3>
                                          <div className="rounded-md border">
                                            <Table>
                                              <TableHeader>
                                                <TableRow>
                                                  <TableHead>Produit</TableHead>
                                                  <TableHead className="text-right">Quantité</TableHead>
                                                  <TableHead className="text-right">Prix unitaire</TableHead>
                                                  <TableHead className="text-right">Total</TableHead>
                                                </TableRow>
                                              </TableHeader>
                                              <TableBody>
                                                {viewingOrder.items.map((item, index) => (
                                                  <TableRow key={index}>
                                                    <TableCell>{item.productName}</TableCell>
                                                    <TableCell className="text-right">{item.quantity}</TableCell>
                                                    <TableCell className="text-right">
                                                      {formatPrice(item.unitPrice)}
                                                    </TableCell>
                                                    <TableCell className="text-right">
                                                      {formatPrice(item.quantity * item.unitPrice)}
                                                    </TableCell>
                                                  </TableRow>
                                                ))}
                                                <TableRow>
                                                  <TableCell colSpan={3} className="text-right font-medium">
                                                    Total
                                                  </TableCell>
                                                  <TableCell className="text-right font-medium">
                                                    {formatPrice(viewingOrder.totalPrice)}
                                                  </TableCell>
                                                </TableRow>
                                              </TableBody>
                                            </Table>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                    <DialogFooter>
                                      <Button onClick={() => setIsViewDialogOpen(false)}>Fermer</Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>
                                {order.status === "READY_FOR_DELIVERY" && (
                                  <Dialog
                                    open={isAssignDeliveryDialogOpen && orderToAssign?.id === order.id}
                                    onOpenChange={(open) => {
                                      setIsAssignDeliveryDialogOpen(open)
                                      if (open) setOrderToAssign(order)
                                      else setOrderToAssign(null)
                                    }}
                                  >
                                    <DialogTrigger asChild>
                                      <Button variant="ghost" size="icon">
                                        <Truck className="h-4 w-4" />
                                        <span className="sr-only">Assigner</span>
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent>
                                      <DialogHeader>
                                        <DialogTitle>Assigner un livreur</DialogTitle>
                                        <DialogDescription>
                                          Sélectionnez un livreur pour la commande {order.referenceId}
                                        </DialogDescription>
                                      </DialogHeader>
                                      <div className="grid gap-4 py-4">
                                        <div className="grid gap-2">
                                          <Label htmlFor="delivery-person">Livreur</Label>
                                          <Select
                                            value={selectedDeliveryPerson}
                                            onValueChange={setSelectedDeliveryPerson}
                                          >
                                            <SelectTrigger id="delivery-person">
                                              <SelectValue placeholder="Sélectionnez un livreur" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              <SelectItem value="1">Pierre Dupont</SelectItem>
                                              <SelectItem value="2">Marie Lambert</SelectItem>
                                              <SelectItem value="3">Jean Martin</SelectItem>
                                            </SelectContent>
                                          </Select>
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor="delivery-date">Date de livraison prévue</Label>
                                          <div className="flex gap-2">
                                            <Input
                                              id="delivery-date"
                                              type="date"
                                              defaultValue={new Date().toISOString().split("T")[0]}
                                            />
                                            <Input id="delivery-time" type="time" defaultValue="08:00" />
                                          </div>
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor="delivery-notes">Notes pour le livreur</Label>
                                          <Textarea
                                            id="delivery-notes"
                                            placeholder="Instructions spéciales pour la livraison..."
                                          />
                                        </div>
                                      </div>
                                      <DialogFooter>
                                        <Button variant="outline" onClick={() => setIsAssignDeliveryDialogOpen(false)}>
                                          Annuler
                                        </Button>
                                        <Button onClick={handleAssignDelivery}>Assigner</Button>
                                      </DialogFooter>
                                    </DialogContent>
                                  </Dialog>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs will show the same content but filtered by status */}
          <TabsContent value="pending" className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Commandes en attente</CardTitle>
                <CardDescription>{filteredOrders.length} commandes trouvées</CardDescription>
              </CardHeader>
              <CardContent>
                {/* Same table content as above */}
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Référence</TableHead>
                        <TableHead>Boulangerie</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Montant</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredOrders.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8">
                            Aucune commande en attente
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredOrders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">{order.referenceId}</TableCell>
                            <TableCell>{order.bakeryName}</TableCell>
                            <TableCell>{formatDate(order.createdAt)}</TableCell>
                            <TableCell>{formatPrice(order.totalPrice)}</TableCell>
                            <TableCell>{getStatusBadge(order.status)}</TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setViewingOrder(order)
                                  setIsViewDialogOpen(true)
                                }}
                              >
                                <Eye className="h-4 w-4" />
                                <span className="sr-only">Voir</span>
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Similar content for other tabs */}
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
