"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SettingsPage() {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  // General settings
  const [companyName, setCompanyName] = useState("Boulangerie Manager")
  const [emailContact, setEmailContact] = useState("contact@boulangerie-manager.fr")
  const [phoneContact, setPhoneContact] = useState("+33 1 23 45 67 89")
  const [address, setAddress] = useState("123 Avenue des Champs-Élysées, 75008 Paris")

  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [smsNotifications, setSmsNotifications] = useState(false)
  const [pushNotifications, setPushNotifications] = useState(true)

  // Security settings
  const [twoFactorAuth, setTwoFactorAuth] = useState(false)
  const [passwordExpiration, setPasswordExpiration] = useState("90")
  const [sessionTimeout, setSessionTimeout] = useState("30")

  // Backup settings
  const [autoBackup, setAutoBackup] = useState(true)
  const [backupFrequency, setBackupFrequency] = useState("daily")
  const [backupRetention, setBackupRetention] = useState("30")

  // Handle form submission
  const handleSaveGeneral = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Paramètres enregistrés",
        description: "Les paramètres généraux ont été mis à jour avec succès.",
      })
    }, 1000)
  }

  const handleSaveNotifications = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Paramètres enregistrés",
        description: "Les paramètres de notification ont été mis à jour avec succès.",
      })
    }, 1000)
  }

  const handleSaveSecurity = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Paramètres enregistrés",
        description: "Les paramètres de sécurité ont été mis à jour avec succès.",
      })
    }, 1000)
  }

  const handleSaveBackup = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Paramètres enregistrés",
        description: "Les paramètres de sauvegarde ont été mis à jour avec succès.",
      })
    }, 1000)
  }

  return (
    <DashboardLayout role="admin">
      <div className="flex flex-col gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Paramètres</h1>
          <p className="text-muted-foreground">Configurez les paramètres du système</p>
        </div>

        <Tabs defaultValue="general" className="space-y-4">
          <TabsList>
            <TabsTrigger value="general">Général</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="security">Sécurité</TabsTrigger>
            <TabsTrigger value="backup">Sauvegardes</TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>Paramètres généraux</CardTitle>
                <CardDescription>Configurez les informations générales de l'application</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="company-name">Nom de l'entreprise</Label>
                  <Input id="company-name" value={companyName} onChange={(e) => setCompanyName(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email-contact">Email de contact</Label>
                  <Input
                    id="email-contact"
                    type="email"
                    value={emailContact}
                    onChange={(e) => setEmailContact(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone-contact">Téléphone de contact</Label>
                  <Input id="phone-contact" value={phoneContact} onChange={(e) => setPhoneContact(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Adresse</Label>
                  <Textarea id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="logo">Logo de l'entreprise</Label>
                  <div className="flex items-center gap-4">
                    <div className="h-16 w-16 rounded-md bg-muted flex items-center justify-center">
                      <span className="text-muted-foreground">Logo</span>
                    </div>
                    <Button variant="outline" size="sm">
                      Changer
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveGeneral} disabled={isLoading}>
                  {isLoading ? "Enregistrement..." : "Enregistrer les modifications"}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Paramètres de notification</CardTitle>
                <CardDescription>Configurez comment et quand les notifications sont envoyées</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications">Notifications par email</Label>
                    <p className="text-sm text-muted-foreground">
                      Recevoir des notifications par email pour les nouvelles commandes et mises à jour
                    </p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sms-notifications">Notifications par SMS</Label>
                    <p className="text-sm text-muted-foreground">
                      Recevoir des notifications par SMS pour les événements urgents
                    </p>
                  </div>
                  <Switch id="sms-notifications" checked={smsNotifications} onCheckedChange={setSmsNotifications} />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="push-notifications">Notifications push</Label>
                    <p className="text-sm text-muted-foreground">Recevoir des notifications push dans l'application</p>
                  </div>
                  <Switch id="push-notifications" checked={pushNotifications} onCheckedChange={setPushNotifications} />
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveNotifications} disabled={isLoading}>
                  {isLoading ? "Enregistrement..." : "Enregistrer les modifications"}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Paramètres de sécurité</CardTitle>
                <CardDescription>Configurez les options de sécurité du système</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="two-factor-auth">Authentification à deux facteurs</Label>
                    <p className="text-sm text-muted-foreground">
                      Exiger une authentification à deux facteurs pour tous les utilisateurs
                    </p>
                  </div>
                  <Switch id="two-factor-auth" checked={twoFactorAuth} onCheckedChange={setTwoFactorAuth} />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="password-expiration">Expiration des mots de passe (jours)</Label>
                  <Input
                    id="password-expiration"
                    type="number"
                    value={passwordExpiration}
                    onChange={(e) => setPasswordExpiration(e.target.value)}
                  />
                  <p className="text-sm text-muted-foreground">
                    Nombre de jours avant qu'un mot de passe n'expire (0 pour désactiver)
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="session-timeout">Délai d'expiration de session (minutes)</Label>
                  <Input
                    id="session-timeout"
                    type="number"
                    value={sessionTimeout}
                    onChange={(e) => setSessionTimeout(e.target.value)}
                  />
                  <p className="text-sm text-muted-foreground">Durée d'inactivité avant déconnexion automatique</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveSecurity} disabled={isLoading}>
                  {isLoading ? "Enregistrement..." : "Enregistrer les modifications"}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="backup">
            <Card>
              <CardHeader>
                <CardTitle>Paramètres de sauvegarde</CardTitle>
                <CardDescription>Configurez les options de sauvegarde automatique</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="auto-backup">Sauvegarde automatique</Label>
                    <p className="text-sm text-muted-foreground">Activer les sauvegardes automatiques du système</p>
                  </div>
                  <Switch id="auto-backup" checked={autoBackup} onCheckedChange={setAutoBackup} />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="backup-frequency">Fréquence des sauvegardes</Label>
                  <Select value={backupFrequency} onValueChange={setBackupFrequency} disabled={!autoBackup}>
                    <SelectTrigger id="backup-frequency">
                      <SelectValue placeholder="Sélectionnez une fréquence" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Toutes les heures</SelectItem>
                      <SelectItem value="daily">Quotidienne</SelectItem>
                      <SelectItem value="weekly">Hebdomadaire</SelectItem>
                      <SelectItem value="monthly">Mensuelle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="backup-retention">Conservation des sauvegardes (jours)</Label>
                  <Input
                    id="backup-retention"
                    type="number"
                    value={backupRetention}
                    onChange={(e) => setBackupRetention(e.target.value)}
                    disabled={!autoBackup}
                  />
                  <p className="text-sm text-muted-foreground">
                    Durée de conservation des sauvegardes avant suppression automatique
                  </p>
                </div>

                <div className="pt-4">
                  <Button variant="outline" disabled={isLoading}>
                    Lancer une sauvegarde manuelle
                  </Button>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveBackup} disabled={isLoading}>
                  {isLoading ? "Enregistrement..." : "Enregistrer les modifications"}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
